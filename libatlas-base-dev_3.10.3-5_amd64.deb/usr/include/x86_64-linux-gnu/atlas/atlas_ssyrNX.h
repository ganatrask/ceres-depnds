#ifndef ATLAS_SSYR_H
   #define ATLAS_SSYR_H
   #define ATL_S1NX 56
#endif
