/*
 * This file generated on line 754 of /build/atlas-jedIp7/atlas-3.10.3/build/..//tune/blas/ger/r2hgen.c
 */
#ifndef ATLAS_ZR2KERNELS_H
   #define ATLAS_ZR2KERNELS_H

void ATL_zger2k__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_zger2k__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_zger2k__900003
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);
void ATL_zger2k__900001
   (ATL_CINT, ATL_CINT, const double*, const double*, const double*,
    const double*, double*, ATL_CINT);


#endif /* end guard around atlas_zr2kernels.h */
