/*
 * This file generated on line 399 of /build/atlas-jedIp7/atlas-3.10.3/build/..//tune/blas/gemv/mvnhgen.c
 */
#ifndef ATLAS_DMVNKERNELS_H
   #define ATLAS_DMVNKERNELS_H

void ATL_dmvnk__900001(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900001_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900003(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900003_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900003(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900003_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900001(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);
void ATL_dmvnk__900001_b0(ATL_CINT, ATL_CINT, const double*, ATL_CINT, const double*, double*);


#endif /* end guard around atlas_dmvnkernels.h */
