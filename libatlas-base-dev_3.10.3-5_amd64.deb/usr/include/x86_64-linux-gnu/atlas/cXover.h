#ifndef CXOVER_H
#define CXOVER_H

#define ATL_3NB 168
#define NN_MNK_M 157304
#define NN_MNK_N 5600
#define NN_MNK_MN 119168
#define NN_MNK_K 157304
#define NN_MNK_GE 103823
#define NT_MNK_M 80864
#define NT_MNK_N 5600
#define NT_MNK_MN 31360
#define NT_MNK_K 157304
#define NT_MNK_GE 103823
#define TN_MNK_M 80864
#define TN_MNK_N 80864
#define TN_MNK_MN 119168
#define TN_MNK_K 12600
#define TN_MNK_GE 54872
#define TT_MNK_M 123704
#define TT_MNK_N 80864
#define TT_MNK_MN 119168
#define TT_MNK_K 12600
#define TT_MNK_GE 103823
#define C2R_K 385

#endif
